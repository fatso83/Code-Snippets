/* 	Eight Queens solution program
   	Start date: 2006-08-08 
	Functioning date: 2006-08-12
	Author: Carl-Erik Kopseng  <carlerik@gmail.com>
   	Purpose: Solve the eight queens problem by backtracking
*/

#include <stdio.h>            
#include "main.h"

#ifndef NMBR
#define NMBR 7
#endif

int main(int argc, char *argv[])
{

	int queens[NMBR], i;
	for(i=0; i<NMBR ; i++) queens[i]=-1;
	queens[0]=0;

	backtrack(queens, 0, NMBR);

	return 0;
	
}	
	

/* bactrack
 * q[] = array containing info on the queens
 * idx = which queen/row
 * sz  = the number of queens
*/
void backtrack( int q[], int row_idx, int sz ){ 
/*	Pseudocode
	The function is called the first time as backtrack(queens,0,0,8)
*/
	int column=0, i;
	if( row_idx == sz ){ //last row was ok
#ifdef DEBUG
	puts("Komplett brett!");
#endif
	        beep();
		draw_chessboard(q,sz);
		return;
	}

	while(column<sz){

#ifdef DEBUG
printf("\nR:%d  C:%d\n", row_idx, column);
//draw_chessboard(q,sz);
#endif

		q[row_idx]=column;
		if( vertical_check(q,sz) == COLLISION ){
#ifdef DEBUG
		        puts("\nVertikal kollisjon");
#endif
			column++;
		}
		else if(diagonal_check(q,sz) == COLLISION){
#ifdef DEBUG
		        puts("\nDiagonal kollisjon");
#endif
			column++;
		}
		else{
			backtrack(q,row_idx+1, sz);			
			//reset rows above this one
			for(i=row_idx+1; i<sz ; i++) q[i]=-1; 
			column++;
		}
			
	}
	return;
}
