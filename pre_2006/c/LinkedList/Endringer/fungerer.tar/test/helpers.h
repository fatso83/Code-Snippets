void hexdump( char*, int );
int readln( char *, int);
void setzero(char *, int );
